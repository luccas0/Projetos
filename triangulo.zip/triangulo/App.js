import React from 'react'
import{View, Text, StyleSheet, TextInput, Button, Alert, document, prompt} from 'react-native'

import getImages from './utils/Triangulos'
 
export default class App extends React.Component{
  constructor(props) {
    super(props)
    this.state = {
      txtA: 0,
      txtB: 0,
      txtC: 0,
    }
  }
 
  botaoClassificar = _ => {
    const {txtA, txtB, txtC} = this.state
    const A = (txtA)
    const B = (txtB)
    const C = (txtC)
 
 
 
 
    if (A == B && B == C){
      Alert.alert("Triângulo Equilátero");
        return
 
    }
 
 
 
 
 
     if (A == B || B == C || C == A){
      Alert.alert("Triângulo Isósceles");
        return
 
    }
    
    else{
      Alert.alert("Triângulo Escaleno");
        return
        }
 
}






    



 
 
 
 
  render(){
    return(
      <View style={styles.container}>
      <TextInput style={styles.A}
      placeholder = "A"
      keyboardType = "numeric"
      onChangeText={txtA => this.setState({txtA})}>
      </TextInput>
 
      <TextInput style={styles.B}
      placeholder = "B"
      keyboardType = "numeric"
      onChangeText={txtB => this.setState({txtB})}>
      </TextInput>
 
      <TextInput style={styles.C}
      placeholder = "C"
      keyboardType = "numeric"
      onChangeText={txtC => this.setState({txtC})}>
      </TextInput>
 
      <View style={styles.Botao}> 
      <Button
      title = "Classifcar"
      onPress={this.botaoClassificar}>
      </Button>
      </View>
      </View>
 
 
 
    );
  }
}
 
const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  A :{
    marginLeft: 10,
    marginTop: 15,
    marginBottom: 5,
    height: 30,
    },
  B: {
    marginLeft: 10,
    marginBottom: 5,
    height: 30,
  },
  C: {
    marginLeft: 10,
    marginBottom: 5,
    height: 30,
  },
  Botao: {
    borderRadius: 100,
    marginVertical: 20,
    width: 120,
    marginTop: 30,
    marginLeft: 115
 
 
  }
 
})