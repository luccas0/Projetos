const images = {
  'Equilatero':require('../assets/equilatero.png'),
  'Escaleno':require('../assets/escaleno.png'),
  'Isoceles':require('../assets/isoceles.png')

};

export default function getImage(Triangle) {
  return images[Triangle]

}